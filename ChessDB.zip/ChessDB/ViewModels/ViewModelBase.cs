using ReactiveUI;

namespace ChessDB.ViewModels
{
    public class ViewModelBase : ReactiveObject
    {
    }
}
